# aluraPlus2025

Este site foi desenvolvido baseado no design disponível no curso da Alura. Trata-se de um site de propaganda de um sistema de Streaming
Desenvolvido por Lucas M. Camacho para a disciplina de programação fornt-end no colégio Antonio de Moraes.
